#Project Details

This project is regarding testing the provided _feed Reader_.I did this Project By undertaking
**javascript Testing course** in udacity.

##Instruction

- To check the testing result open `index.html` file, at the bottom of the page results is displayed.
- The testing is done using _Jasmine Testing suit_.

##Testing Details

- Test on __allFeeds function__.
- Test on __menu function__.
- Test on __loadFeed function__.
- Test on __Feed Entries__.
